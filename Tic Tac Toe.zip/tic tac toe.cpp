 #include <iostream>
 using namespace std;

 
class Board {
protected:
    char board[3][3];

public:
    Board() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                board[i][j] = '-';
            }
        }
    }

    void display() {
        cout << "-------------" << endl;
        for (int i = 0; i < 3; i++) {
            cout << "| ";
            for (int j = 0; j < 3; j++) {
                cout << board[i][j] << " | ";
            }
            cout << endl;
            cout << "-------------" << endl;
        }
    }

    bool isFilled(int row, int col) {
        if (board[row][col] == '-') {
            return false;
        }
        return true;
    }

    void makeMove(int row, int col, char player) {
        board[row][col] = player;
    }

    char checkWinner() {
         
        for (int i = 0; i < 3; i++) {
            if (board[i][0] == board[i][1] && board[i][1] == board[i][2]) {
                return board[i][0];
            }
        }

      
        for (int i = 0; i < 3; i++) {
            if (board[0][i] == board[1][i] && board[1][i] == board[2][i]) {
                return board[0][i];
            }
        }

 
        if (board[0][0] == board[1][1] && board[1][1] == board[2][2]) {
            return board[0][0];
        }

        if (board[0][2] == board[1][1] && board[1][1] == board[2][0]) {
            return board[0][2];
        }

        return '-';
    }
};

 
class Player : public Board {
private:
    char symbol;

public:
    Player(char s) {
        symbol = s;
    }

    char getSymbol() {
        return symbol;
    }

    void makeMove(int row, int col) {
        Board::makeMove(row, col, symbol);
    }
};

int main() {
    Player player1('X');
    Player player2('O');
    Board gameBoard;
    int row, col;
    char winner = '-';

    cout << "Tic Tac Toe Game" << endl;
    gameBoard.display();

    while (winner == '-') {
        // player 1 turn
        do {
            cout << "Player 1's turn (X): ";
            cin >> row >> col;
        } while (gameBoard.isFilled(row, col));

        player1.makeMove(row, col);
        gameBoard.display();
        winner = gameBoard.checkWinner();
        if (winner != '-') {
            break;
        }

        // player 2 turn
        do {
            cout << "Player 2's turn (O): ";
            cin >> row >> col;
        } while (gameBoard.isFilled(row, col));

        player2.makeMove(row, col);
        gameBoard.display();
        winner = gameBoard.checkWinner();
    }

    if (winner == 'X') {
        cout << "Player 1 (X) wins"<<endl;
} else if (winner == 'O') {
    cout << "Player 2 (O) wins" << endl;
} else {
    cout << "It's a tie" << endl;
}

return 0;
}


